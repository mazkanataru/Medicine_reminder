package com.example.health

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
