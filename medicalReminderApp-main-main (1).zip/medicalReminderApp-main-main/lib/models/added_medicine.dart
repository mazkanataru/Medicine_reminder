class AddedMedicine {
  String? name;
  String? addedTime;
  AddedMedicine({this.name, this.addedTime});
}