class Keys {
  static const token = 'access_token';
}
